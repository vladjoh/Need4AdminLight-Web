(function () {
    var storageKey = 'n4a-app-cols';
    var defs = [
        { key: 'risk', label: 'Exposure' },
        { key: 'name', label: 'Application' },
        { key: 'appid', label: 'App (client) ID' },
        { key: 'lastused', label: 'Last used' },
        { key: 'lastmod', label: 'Last modified' },
        { key: 'addedon', label: 'Added on' },
        { key: 'origin', label: 'Origin' },
        { key: 'lastsignin', label: 'Last sign-in' },
        { key: 'cert', label: 'Certificate' },
        { key: 'secret', label: 'Client secret' },
        { key: 'dr', label: 'Delegated read permissions' },
        { key: 'dw', label: 'Delegated write permissions' },
        { key: 'ar', label: 'Application read permissions' },
        { key: 'aw', label: 'Application write permissions' },
        { key: 'dall', label: 'Delegated permissions (all)' },
        { key: 'aall', label: 'Application permissions (all)' }
    ];

    function loadHidden() {
        try {
            var raw = sessionStorage.getItem(storageKey);
            if (!raw) return {};
            return JSON.parse(raw);
        } catch (e) {
            return {};
        }
    }

    function saveHidden(map) {
        try {
            sessionStorage.setItem(storageKey, JSON.stringify(map));
        } catch (e) { /* ignore */ }
    }

    function applyVisibility(table, hiddenMap) {
        defs.forEach(function (d) {
            var hide = !!hiddenMap[d.key];
            table.querySelectorAll('.app-col--' + d.key).forEach(function (el) {
                el.classList.toggle('app-col-hidden', hide);
            });
        });
    }

    function norm(s) {
        return (s || '').trim().toLowerCase();
    }

    function compareValues(a, b, asc) {
        var sa = a ?? '';
        var sb = b ?? '';
        if (sa !== '' && sb !== '' && /^\d+$/.test(sa) && /^\d+$/.test(sb) && sa.length === sb.length) {
            var c = sa < sb ? -1 : sa > sb ? 1 : 0;
            return asc ? c : -c;
        }
        var na = parseFloat(sa);
        var nb = parseFloat(sb);
        if (sa !== '' && sb !== '' && !isNaN(na) && !isNaN(nb) && na !== nb) {
            return asc ? na - nb : nb - na;
        }
        var c = String(sa).localeCompare(String(sb), undefined, { sensitivity: 'base' });
        return asc ? c : -c;
    }

    function sortByKey(table, key, asc) {
        var tbody = table.querySelector('tbody');
        if (!tbody) return;
        var rows = Array.from(tbody.querySelectorAll('tr'));
        rows.sort(function (ra, rb) {
            var va = ra.getAttribute('data-sort-' + key) || '';
            var vb = rb.getAttribute('data-sort-' + key) || '';
            var c = compareValues(va, vb, asc);
            if (c !== 0) return c;
            var ua = ra.getAttribute('data-sort-name') || '';
            var ub = rb.getAttribute('data-sort-name') || '';
            return String(ua).localeCompare(String(ub), undefined, { sensitivity: 'base' });
        });
        rows.forEach(function (r) { tbody.appendChild(r); });
    }

    function applyRowFilters(table) {
        var tbody = table.querySelector('tbody');
        if (!tbody) return;

        var searchEl = document.getElementById('search-applications');
        var q = norm(searchEl ? searchEl.value : '');
        var permSel = document.getElementById('app-filter-perm');
        var permVal = permSel ? permSel.value : '';

        tbody.querySelectorAll('tr').forEach(function (tr) {
            var hide = false;

            if (!hide && q) {
                var t = norm(tr.textContent || '');
                if (t.indexOf(q) < 0) hide = true;
            }

            if (!hide && permVal) {
                var readCount = parseInt(tr.getAttribute('data-filter-read') || '0', 10);
                var writeCount = parseInt(tr.getAttribute('data-filter-write') || '0', 10);
                if (permVal === 'read' && !(readCount > 0)) hide = true;
                if (permVal === 'read-write' && !(writeCount > 0)) hide = true;
            }

            tr.classList.toggle('report-row-hidden', hide);
        });
    }

    function init() {
        var table = document.getElementById('tbl-applications');
        var host = document.getElementById('app-col-checks');
        if (!table || !host) return;

        var hiddenMap = loadHidden();

        defs.forEach(function (d) {
            var id = 'app-col-' + d.key;
            var wrap = document.createElement('div');
            wrap.className = 'form-check mb-1';
            var chk = document.createElement('input');
            chk.type = 'checkbox';
            chk.className = 'form-check-input';
            chk.id = id;
            chk.checked = !hiddenMap[d.key];
            chk.dataset.colKey = d.key;
            var lab = document.createElement('label');
            lab.className = 'form-check-label small';
            lab.setAttribute('for', id);
            lab.textContent = d.label;
            wrap.appendChild(chk);
            wrap.appendChild(lab);
            host.appendChild(wrap);

            chk.addEventListener('change', function () {
                if (chk.checked) {
                    delete hiddenMap[d.key];
                } else {
                    hiddenMap[d.key] = true;
                }
                saveHidden(hiddenMap);
                applyVisibility(table, hiddenMap);
            });
        });

        applyVisibility(table, hiddenMap);

        var searchEl = document.getElementById('search-applications');
        if (searchEl) searchEl.addEventListener('input', function () { applyRowFilters(table); });
        var permSel = document.getElementById('app-filter-perm');
        if (permSel) permSel.addEventListener('change', function () { applyRowFilters(table); });
        var sortApply = document.getElementById('app-sort-apply');
        var sortKey = document.getElementById('app-sort-key');
        var sortDir = document.getElementById('app-sort-dir');
        if (sortApply && sortKey && sortDir) {
            sortApply.addEventListener('click', function () {
                sortByKey(table, sortKey.value || 'risk', (sortDir.value || 'desc') === 'asc');
                applyRowFilters(table);
            });
        }

        // Default to exposure desc on first load.
        sortByKey(table, 'risk', false);
        applyRowFilters(table);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
