(function () {
    var storageKey = 'n4a-priv-cols';
    var defs = [
        { key: 'risk', label: 'Exposure' },
        { key: 'upn', label: 'UPN' },
        { key: 'ea', label: 'Entra active' },
        { key: 'ee', label: 'Entra eligible' },
        { key: 'pim-entra', label: 'PIM groups Entra roles' },
        { key: 'aa', label: 'Azure active' },
        { key: 'ae', label: 'Azure eligible' },
        { key: 'pim-azure', label: 'PIM groups Azure roles' },
        { key: 'tot', label: 'Total roles' },
        { key: 'act', label: 'Status' },
        { key: 'ut', label: 'Type' },
        { key: 'mfa', label: 'MFA' },
        { key: 'phish', label: 'Phishing-resistant' },
        { key: 'stale', label: 'Stale account' },
        { key: 'li', label: 'Last interactive' },
        { key: 'ln', label: 'Last non-interactive' },
        { key: 'auth', label: 'Auth methods' }
    ];

    function loadHidden() {
        try {
            var raw = sessionStorage.getItem(storageKey);
            if (!raw) return {};
            return JSON.parse(raw);
        } catch (e) {
            return {};
        }
    }

    function saveHidden(map) {
        try {
            sessionStorage.setItem(storageKey, JSON.stringify(map));
        } catch (e) { /* ignore */ }
    }

    function applyVisibility(table, hiddenMap) {
        defs.forEach(function (d) {
            var hide = !!hiddenMap[d.key];
            table.querySelectorAll('.pri-col--' + d.key).forEach(function (el) {
                el.classList.toggle('pri-col-hidden', hide);
            });
        });
    }

    function norm(s) {
        return (s || '').trim().toLowerCase();
    }

    function compareValues(a, b, asc) {
        var sa = a ?? '';
        var sb = b ?? '';
        var na = parseFloat(sa);
        var nb = parseFloat(sb);
        if (sa !== '' && sb !== '' && !isNaN(na) && !isNaN(nb) && na !== nb) {
            return asc ? na - nb : nb - na;
        }
        var c = String(sa).localeCompare(String(sb), undefined, { sensitivity: 'base' });
        return asc ? c : -c;
    }

    function sortByKey(table, key, asc) {
        var tbody = table.querySelector('tbody');
        if (!tbody) return;
        var rows = Array.from(tbody.querySelectorAll('tr'));
        rows.sort(function (ra, rb) {
            var va = ra.getAttribute('data-sort-' + key) || '';
            var vb = rb.getAttribute('data-sort-' + key) || '';
            var c = compareValues(va, vb, asc);
            if (c !== 0) return c;
            var ua = ra.getAttribute('data-sort-upn') || '';
            var ub = rb.getAttribute('data-sort-upn') || '';
            return String(ua).localeCompare(String(ub), undefined, { sensitivity: 'base' });
        });
        rows.forEach(function (r) { tbody.appendChild(r); });
    }

    function applyRowFilters(table) {
        var tbody = table.querySelector('tbody');
        if (!tbody) return;

        var searchEl = document.getElementById('search-privileged');
        var q = norm(searchEl ? searchEl.value : '');
        var roleSel = document.getElementById('priv-filter-role');
        var roleVal = roleSel ? norm(roleSel.value) : '';
        var authSel = document.getElementById('priv-filter-auth');
        var authVal = authSel ? norm(authSel.value) : '';
        var mfaSel = document.getElementById('priv-filter-mfa');
        var mfaVal = mfaSel ? mfaSel.value : '';
        var phishSel = document.getElementById('priv-filter-phish');
        var phishVal = phishSel ? phishSel.value : '';
        var statusSel = document.getElementById('priv-filter-status');
        var statusVal = statusSel ? statusSel.value : '';
        var staleSel = document.getElementById('priv-filter-stale');
        var staleVal = staleSel ? staleSel.value : '';

        tbody.querySelectorAll('tr').forEach(function (tr) {
            var hide = false;

            if (!hide && roleVal) {
                var roles = norm(tr.getAttribute('data-filter-roles') || '');
                if (roles.indexOf(roleVal) < 0) hide = true;
            }

            if (!hide && authVal) {
                var auth = norm(tr.getAttribute('data-filter-auth') || '');
                if (auth.indexOf(authVal) < 0) hide = true;
            }

            if (!hide && mfaVal) {
                if ((tr.getAttribute('data-filter-mfa') || '') !== mfaVal) hide = true;
            }

            if (!hide && phishVal) {
                if ((tr.getAttribute('data-filter-phish') || '') !== phishVal) hide = true;
            }

            if (!hide && statusVal) {
                if ((tr.getAttribute('data-filter-status') || '') !== statusVal) hide = true;
            }

            if (!hide && staleVal) {
                if ((tr.getAttribute('data-filter-stale') || '') !== staleVal) hide = true;
            }

            if (!hide && q) {
                var t = norm(tr.textContent || '');
                if (t.indexOf(q) < 0) hide = true;
            }

            tr.classList.toggle('report-row-hidden', hide);
        });
    }

    function init() {
        var table = document.getElementById('tbl-privileged');
        var host = document.getElementById('priv-col-checks');
        if (!table || !host) return;

        var hiddenMap = loadHidden();

        defs.forEach(function (d) {
            var id = 'pri-col-' + d.key;
            var wrap = document.createElement('div');
            wrap.className = 'form-check mb-1';
            var chk = document.createElement('input');
            chk.type = 'checkbox';
            chk.className = 'form-check-input';
            chk.id = id;
            chk.checked = !hiddenMap[d.key];
            chk.dataset.colKey = d.key;
            var lab = document.createElement('label');
            lab.className = 'form-check-label small';
            lab.setAttribute('for', id);
            lab.textContent = d.label;
            wrap.appendChild(chk);
            wrap.appendChild(lab);
            host.appendChild(wrap);

            chk.addEventListener('change', function () {
                if (chk.checked) {
                    delete hiddenMap[d.key];
                } else {
                    hiddenMap[d.key] = true;
                }
                saveHidden(hiddenMap);
                applyVisibility(table, hiddenMap);
            });
        });

        applyVisibility(table, hiddenMap);

        var searchEl = document.getElementById('search-privileged');
        if (searchEl) searchEl.addEventListener('input', function () { applyRowFilters(table); });

        ['priv-filter-role', 'priv-filter-auth', 'priv-filter-mfa', 'priv-filter-phish', 'priv-filter-status', 'priv-filter-stale'].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) {
                el.addEventListener('change', function () { applyRowFilters(table); });
                el.addEventListener('input', function () { applyRowFilters(table); });
            }
        });

        var sortApply = document.getElementById('priv-sort-apply');
        var sortKey = document.getElementById('priv-sort-key');
        var sortDir = document.getElementById('priv-sort-dir');
        if (sortApply && sortKey && sortDir) {
            sortApply.addEventListener('click', function () {
                sortByKey(table, sortKey.value || 'risk', (sortDir.value || 'desc') === 'asc');
                applyRowFilters(table);
            });
        }

        // Default to exposure desc on first load.
        sortByKey(table, 'risk', false);
        applyRowFilters(table);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
